﻿using UnityEngine;

public class DH_AutoDespawn : MonoBehaviour
{
    public void DestroySelf()
    {
        Destroy(gameObject);
    }
}
