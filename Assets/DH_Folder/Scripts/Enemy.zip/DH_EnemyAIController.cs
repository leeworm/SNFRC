﻿using UnityEngine;

public class DH_EnemyAIController : MonoBehaviour
{
    private DH_Enemy enemy;
    private Transform player;

    [Header("AI 설정")]
    public float decisionInterval = 0.2f;
    public float attackRange = 2f;
    public float dashRange = 4f;
    public float jumpHeightDifference = 1f;

    private float lastDecisionTime;

    private void Awake()
    {
        enemy = GetComponent<DH_Enemy>();
    }

    private void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player")?.transform;
    }

    private void Update()
    {
        if (player == null || enemy == null || enemy.isDead)
            return;

        if (Time.time - lastDecisionTime < decisionInterval)
            return;

        lastDecisionTime = Time.time;

        Vector2 dirToPlayer = player.position - enemy.transform.position;
        float distance = dirToPlayer.magnitude;

        // 기본 방향 설정
        enemy.inputX = Mathf.Sign(dirToPlayer.x);

        // 어퍼컷 (가까이 있을 때 위로 입력 + 공격)
        if (distance <= 1.2f && player.position.y > enemy.transform.position.y + jumpHeightDifference)
        {
            enemy.isUpInput = true;
            enemy.isAttackInput = true;
            return;
        }

        // 점프 공격 (멀리 위에 있을 때)
        if (distance <= 2f && player.position.y > enemy.transform.position.y + jumpHeightDifference)
        {
            enemy.isJumpInput = true;
            enemy.isAttackInput = true;
            return;
        }

        // 점프 (지형 단차 대응용)
        if (player.position.y > enemy.transform.position.y + jumpHeightDifference)
        {
            enemy.isJumpInput = true;
            return;
        }

        // 대시 (중거리 접근용)
        if (distance >= dashRange && Mathf.Abs(dirToPlayer.x) > 1f)
        {
            enemy.isDashInput = true;
            return;
        }

        // 공격 (사거리 안에 있을 때)
        if (distance <= attackRange)
        {
            enemy.isAttackInput = true;
            return;
        }
    }
}
