﻿using UnityEngine;

public class DH_PlayerHurtState : DH_PlayerGroundedState
{
    private bool isKnockbacking = false;

    public DH_PlayerHurtState(DH_Player _player, DH_PlayerStateMachine _stateMachine, string _animBoolName)
        : base(_player, _stateMachine, _animBoolName) { }

    public override void Enter()
    {
        base.Enter();
        player.isBusy = true;
        player.isHurting = true;
        player.SetVelocity(player.lastKnockback.x, player.lastKnockback.y);

        // 넉백 방향에 따라 애니메이션 선택
        if (Mathf.Abs(player.lastKnockback.y) > 0.1f)
        {
            player.anim.SetBool("Hurt", false);
            player.anim.SetBool("Knockback", true);
            isKnockbacking = true;
        }
    }

    public override void Update()
    {
        base.Update();

        if (rb.linearVelocity.y > 0.1f && !player.IsGrounded())
        {
            player.anim.SetBool("Hurt", false);
            player.anim.SetBool("Knockback", true);
            isKnockbacking = true;
        }

        if (player.isGrounded && isKnockbacking)
        {
            stateMachine.ChangeState(player.knockdownState);
        }
        else if (player.isGrounded)
        {
            stateMachine.ChangeState(player.idleState);
        }
    }

    public override void Exit()
    {
        base.Exit();
        player.isBusy = false;
        player.isHurting = false;
    }
}
