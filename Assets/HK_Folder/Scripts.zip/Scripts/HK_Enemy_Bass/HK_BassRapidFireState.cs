using UnityEngine;

public class HK_BassRapidFireState : HK_IEnemyState
{
    private HK_Enemy_Bass bass;
    private float fireRate = 0.2f; // 발사 주기 (초)
    private float fireTimer; // 발사 타이머
    private int shotsFired; // 발사한 총알 수
    private int maxShots = 5; // 최대 발사 횟수

    public HK_BassRapidFireState(HK_Enemy_Bass bass)
    {
        this.bass = bass;
    }

    public void Enter()
    {
        fireTimer = 0f;
        shotsFired = 0;
        bass.animator.SetTrigger("RapidFire1"); // RapidFire 애니메이션 트리거
    }

    public void Update()
    {
        fireTimer += Time.deltaTime;

        // 일정 주기마다 총알 발사
        if (fireTimer >= fireRate && shotsFired < maxShots)
        {
            fireTimer = 0f;
            shotsFired++;

            // 총알 발사
            GameObject shot = GameObject.Instantiate(bass.rapidShotPrefab, bass.firePoint.position, Quaternion.identity);
            Vector2 direction = (bass.player.position - bass.firePoint.position).normalized;

            // 불렛에 속도 설정 (velocity 사용)
            Rigidbody2D shotRb = shot.GetComponent<Rigidbody2D>();
            if (shotRb != null)
            {
                shotRb.linearVelocity = direction * 12f;  // 총알 속도 설정
            }

            // 총알에 Lifetime을 설정하여 일정 시간 후 삭제
            UnityEngine.Object.Destroy(shot, 2f); // 2초 후 총알 삭제
        }

        // 발사 횟수가 최대에 도달하면 상태 전환
        if (shotsFired >= maxShots)
        {
            bass.stateMachine.ChangeState(new HK_BassMoveState(bass)); // 발사 후 Move 상태로 전환
        }
    }

    public void AnimationFinishTrigger()
    {
        // 애니메이션이 끝났을 때 추가적인 처리가 필요할 경우 여기에 작성
        if (shotsFired >= maxShots)
        {
            bass.stateMachine.ChangeState(new HK_BassMoveState(bass)); // 애니메이션 끝나면 이동 상태로 전환
        }
    }

    public void Exit()
    {
        bass.animator.ResetTrigger("RapidFire1"); // RapidFire 애니메이션 트리거 리셋
    }
}
