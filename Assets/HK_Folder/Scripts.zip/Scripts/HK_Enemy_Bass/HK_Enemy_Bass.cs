using UnityEngine;

public class HK_Enemy_Bass : MonoBehaviour
{
    [Header("Components")]
    public Animator animator;
    public Transform firePoint;

    [Header("Bullet Prefabs")]
    public GameObject rapidShotPrefab;     // RapidFire1 용
    public GameObject rapidShotPrefab2;    // RapidFire2 용

    [Header("Settings")]
    public int maxJumps = 2;
    public float attackRange = 2.0f;
    public float moveSpeed = 2.5f;

    [HideInInspector] public int jumpCount = 0;
    [HideInInspector] public float linearVelocityX = 0f;

    [HideInInspector] public Transform player;
    [HideInInspector] public HK_EnemyStateMachine stateMachine;

    private HK_Health health;

    void Awake()
    {
        if (animator == null)
            animator = GetComponent<Animator>();

        stateMachine = GetComponent<HK_EnemyStateMachine>();
        health = GetComponent<HK_Health>();

        if (health != null)
        {
            health.OnDeath.AddListener(OnDeath);
        }
    }

    void Update()
    {
        stateMachine?.currentState?.Update();
    }

    void OnDeath()
    {
        stateMachine.ChangeState(new HK_BassDeathState(this));
    }

    public void AnimationFinishTrigger()
    {
        stateMachine?.currentState?.AnimationFinishTrigger();
    }

    public void SetVelocity(Vector2 velocity)
    {
        Rigidbody2D rb = GetComponent<Rigidbody2D>();
        if (rb != null)
            rb.linearVelocity = velocity; // 오타 수정: linearVelocity → velocity
    }

    // 🎯 애니메이션 이벤트용 발사 함수들
    public void FireRapidShot1()
    {
        if (rapidShotPrefab != null && firePoint != null)
        {
            Instantiate(rapidShotPrefab, firePoint.position, Quaternion.identity);
        }
    }

    public void FireRapidShot2()
    {
        if (rapidShotPrefab2 != null && firePoint != null)
        {
            Instantiate(rapidShotPrefab2, firePoint.position, Quaternion.identity);
        }
    }
}
